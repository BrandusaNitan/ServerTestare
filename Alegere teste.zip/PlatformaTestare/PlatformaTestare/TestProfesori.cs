﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PlatformaTestare
{
    public partial class TestProfesori : Form
    {
        public TestProfesori(User user)
        {
            InitializeComponent();
            SqlConnection con = new SqlConnection(Helper.ConnectionValue("PlatformaTestare"));
            SqlCommand cmd = new SqlCommand("SELECT * FROM Teste as t JOIN Materii as m ON t.ID_Materie = m.ID_Materie WHERE m.Nume='" + user.materie + "'",con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            BindingSource bSource = new BindingSource();
            bSource.DataSource = dtbl;
            testeGrid.DataSource = bSource;


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
