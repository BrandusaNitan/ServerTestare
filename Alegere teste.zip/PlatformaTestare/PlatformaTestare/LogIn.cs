﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PlatformaTestare
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void logInButton_Click(object sender, EventArgs e)
        {

            bool isProf = false;
            SqlConnection sqlcon = new SqlConnection(Helper.ConnectionValue("PlatformaTestare"));
            sqlcon.Open();

            Encrypter encryptPassword = new Encrypter();
            SqlCommand cmd = new SqlCommand("SELECT * FROM [UtilizatoriStudenti] WHERE username ='" + usernameTextBox.Text + "' and parola = '" + encryptPassword.encryptPassword(passwrodTextBox.Text) + "'",sqlcon);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            if (dtbl.Rows.Count > 0)
            {
                string username;
                username = dtbl.Rows[0][1].ToString();
                User user = new User(username, isProf);
                this.Hide();
                MainMenu openMainMenu = new MainMenu(user);
                openMainMenu.Show();
            }
            else
            {
                DataTable dtbl2 = new DataTable();
                SqlCommand cmd2 = new SqlCommand("SELECT * FROM [UtilizatoriProfesori] WHERE username ='" + usernameTextBox.Text + "' and parola = '" + encryptPassword.encryptPassword(passwrodTextBox.Text) + "'", sqlcon);
                SqlDataAdapter sda2 = new SqlDataAdapter(cmd2);
                sda2.Fill(dtbl2);
                if (dtbl2.Rows.Count > 0 && dtbl.Rows.Count == 0)
                {
                    isProf = true;
                    string username;
                    username = dtbl2.Rows[0][1].ToString();
                    SqlCommand cmd3 = new SqlCommand("SELECT m.Nume FROM Materii as m JOIN Profesori as p ON m.ID_Materie = p.ID_Materie JOIN UtilizatoriProfesori as u ON p.ID_Profesor = u.ID_UtilizatorProfesor WHERE username = '" + username + "'",sqlcon);
                    DataTable dtbl3 = new DataTable();
                    SqlDataAdapter sda3 = new SqlDataAdapter(cmd3);
                    sda3.Fill(dtbl3);
                    User user = new User(username, isProf);
                    user.materie = dtbl3.Rows[0][0].ToString();
                    this.Hide();
                    MainMenu openMainMenu = new MainMenu(user);
                    openMainMenu.Show();

                }
                else if (dtbl.Rows.Count == 0)
                    MessageBox.Show("Wrong username or password!");
            }
       
           
            sqlcon.Close();
        }





        private void registerButton_Click(object sender, EventArgs e)
        {
            Register openRegister = new Register();
            openRegister.Show();
            this.Hide();
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void usernameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void passwrodTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
