﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlatformaTestare
{
    public class User
    {
        public String name;
        public bool isProf;
        public String materie;

        public User(string name, bool isProf)
        {
            this.name = name;
            this.isProf = isProf;
        }
        public User()
        {

        }
        public void assign(string name, bool isProf,string materie)
        {
            this.name = name;
            this.isProf = isProf;
            this.materie = materie;
        }
    }
}
