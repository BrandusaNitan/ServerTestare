﻿namespace PlatformaTestare
{
    partial class TestMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.a1q1 = new System.Windows.Forms.RadioButton();
            this.a2q1 = new System.Windows.Forms.RadioButton();
            this.a3q1 = new System.Windows.Forms.RadioButton();
            this.a4q1 = new System.Windows.Forms.RadioButton();
            this.a4q2 = new System.Windows.Forms.RadioButton();
            this.a3q2 = new System.Windows.Forms.RadioButton();
            this.a2q2 = new System.Windows.Forms.RadioButton();
            this.a1q2 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.a4q3 = new System.Windows.Forms.RadioButton();
            this.a3q3 = new System.Windows.Forms.RadioButton();
            this.a2q3 = new System.Windows.Forms.RadioButton();
            this.a1q3 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.a4q4 = new System.Windows.Forms.RadioButton();
            this.a3q4 = new System.Windows.Forms.RadioButton();
            this.a2q4 = new System.Windows.Forms.RadioButton();
            this.a1q4 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.a4q5 = new System.Windows.Forms.RadioButton();
            this.a3q5 = new System.Windows.Forms.RadioButton();
            this.a2q5 = new System.Windows.Forms.RadioButton();
            this.a1q5 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.a4q6 = new System.Windows.Forms.RadioButton();
            this.a3q6 = new System.Windows.Forms.RadioButton();
            this.a2q6 = new System.Windows.Forms.RadioButton();
            this.a1q6 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.a4q7 = new System.Windows.Forms.RadioButton();
            this.a3q7 = new System.Windows.Forms.RadioButton();
            this.a2q7 = new System.Windows.Forms.RadioButton();
            this.a1q7 = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.a4q8 = new System.Windows.Forms.RadioButton();
            this.a3q8 = new System.Windows.Forms.RadioButton();
            this.a2q8 = new System.Windows.Forms.RadioButton();
            this.a1q8 = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.a4q9 = new System.Windows.Forms.RadioButton();
            this.a3q9 = new System.Windows.Forms.RadioButton();
            this.a2q9 = new System.Windows.Forms.RadioButton();
            this.a1q9 = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.a4q10 = new System.Windows.Forms.RadioButton();
            this.a3q10 = new System.Windows.Forms.RadioButton();
            this.a2q10 = new System.Windows.Forms.RadioButton();
            this.a1q10 = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.finishButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // a1q1
            // 
            this.a1q1.AutoSize = true;
            this.a1q1.Location = new System.Drawing.Point(9, 46);
            this.a1q1.Name = "a1q1";
            this.a1q1.Size = new System.Drawing.Size(95, 17);
            this.a1q1.TabIndex = 1;
            this.a1q1.TabStop = true;
            this.a1q1.Text = "answer1check";
            this.a1q1.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.a1q1.UseVisualStyleBackColor = true;
            // 
            // a2q1
            // 
            this.a2q1.AutoSize = true;
            this.a2q1.Location = new System.Drawing.Point(9, 70);
            this.a2q1.Name = "a2q1";
            this.a2q1.Size = new System.Drawing.Size(85, 17);
            this.a2q1.TabIndex = 2;
            this.a2q1.TabStop = true;
            this.a2q1.Text = "radioButton2";
            this.a2q1.UseVisualStyleBackColor = true;
            this.a2q1.CheckedChanged += new System.EventHandler(this.a2q1_CheckedChanged);
            // 
            // a3q1
            // 
            this.a3q1.AutoSize = true;
            this.a3q1.Location = new System.Drawing.Point(9, 94);
            this.a3q1.Name = "a3q1";
            this.a3q1.Size = new System.Drawing.Size(85, 17);
            this.a3q1.TabIndex = 3;
            this.a3q1.TabStop = true;
            this.a3q1.Text = "radioButton3";
            this.a3q1.UseVisualStyleBackColor = true;
            this.a3q1.CheckedChanged += new System.EventHandler(this.a3q1_CheckedChanged);
            // 
            // a4q1
            // 
            this.a4q1.AutoSize = true;
            this.a4q1.Location = new System.Drawing.Point(9, 118);
            this.a4q1.Name = "a4q1";
            this.a4q1.Size = new System.Drawing.Size(85, 17);
            this.a4q1.TabIndex = 4;
            this.a4q1.TabStop = true;
            this.a4q1.Text = "radioButton4";
            this.a4q1.UseVisualStyleBackColor = true;
            // 
            // a4q2
            // 
            this.a4q2.AutoSize = true;
            this.a4q2.Location = new System.Drawing.Point(9, 115);
            this.a4q2.Name = "a4q2";
            this.a4q2.Size = new System.Drawing.Size(85, 17);
            this.a4q2.TabIndex = 9;
            this.a4q2.TabStop = true;
            this.a4q2.Text = "radioButton4";
            this.a4q2.UseVisualStyleBackColor = true;
            // 
            // a3q2
            // 
            this.a3q2.AutoSize = true;
            this.a3q2.Location = new System.Drawing.Point(9, 91);
            this.a3q2.Name = "a3q2";
            this.a3q2.Size = new System.Drawing.Size(85, 17);
            this.a3q2.TabIndex = 8;
            this.a3q2.TabStop = true;
            this.a3q2.Text = "radioButton3";
            this.a3q2.UseVisualStyleBackColor = true;
            // 
            // a2q2
            // 
            this.a2q2.AutoSize = true;
            this.a2q2.Location = new System.Drawing.Point(9, 67);
            this.a2q2.Name = "a2q2";
            this.a2q2.Size = new System.Drawing.Size(85, 17);
            this.a2q2.TabIndex = 7;
            this.a2q2.TabStop = true;
            this.a2q2.Text = "radioButton2";
            this.a2q2.UseVisualStyleBackColor = true;
            // 
            // a1q2
            // 
            this.a1q2.AutoSize = true;
            this.a1q2.Location = new System.Drawing.Point(9, 43);
            this.a1q2.Name = "a1q2";
            this.a1q2.Size = new System.Drawing.Size(95, 17);
            this.a1q2.TabIndex = 6;
            this.a1q2.TabStop = true;
            this.a1q2.Text = "answer1check";
            this.a1q2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.a1q2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "label2";
            // 
            // a4q3
            // 
            this.a4q3.AutoSize = true;
            this.a4q3.Location = new System.Drawing.Point(9, 114);
            this.a4q3.Name = "a4q3";
            this.a4q3.Size = new System.Drawing.Size(85, 17);
            this.a4q3.TabIndex = 14;
            this.a4q3.TabStop = true;
            this.a4q3.Text = "radioButton4";
            this.a4q3.UseVisualStyleBackColor = true;
            // 
            // a3q3
            // 
            this.a3q3.AutoSize = true;
            this.a3q3.Location = new System.Drawing.Point(9, 90);
            this.a3q3.Name = "a3q3";
            this.a3q3.Size = new System.Drawing.Size(85, 17);
            this.a3q3.TabIndex = 13;
            this.a3q3.TabStop = true;
            this.a3q3.Text = "radioButton3";
            this.a3q3.UseVisualStyleBackColor = true;
            // 
            // a2q3
            // 
            this.a2q3.AutoSize = true;
            this.a2q3.Location = new System.Drawing.Point(9, 66);
            this.a2q3.Name = "a2q3";
            this.a2q3.Size = new System.Drawing.Size(85, 17);
            this.a2q3.TabIndex = 12;
            this.a2q3.TabStop = true;
            this.a2q3.Text = "radioButton2";
            this.a2q3.UseVisualStyleBackColor = true;
            // 
            // a1q3
            // 
            this.a1q3.AutoSize = true;
            this.a1q3.Location = new System.Drawing.Point(9, 42);
            this.a1q3.Name = "a1q3";
            this.a1q3.Size = new System.Drawing.Size(95, 17);
            this.a1q3.TabIndex = 11;
            this.a1q3.TabStop = true;
            this.a1q3.Text = "answer1check";
            this.a1q3.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.a1q3.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "label3";
            // 
            // a4q4
            // 
            this.a4q4.AutoSize = true;
            this.a4q4.Location = new System.Drawing.Point(9, 118);
            this.a4q4.Name = "a4q4";
            this.a4q4.Size = new System.Drawing.Size(85, 17);
            this.a4q4.TabIndex = 19;
            this.a4q4.TabStop = true;
            this.a4q4.Text = "radioButton4";
            this.a4q4.UseVisualStyleBackColor = true;
            // 
            // a3q4
            // 
            this.a3q4.AutoSize = true;
            this.a3q4.Location = new System.Drawing.Point(9, 94);
            this.a3q4.Name = "a3q4";
            this.a3q4.Size = new System.Drawing.Size(85, 17);
            this.a3q4.TabIndex = 18;
            this.a3q4.TabStop = true;
            this.a3q4.Text = "radioButton3";
            this.a3q4.UseVisualStyleBackColor = true;
            // 
            // a2q4
            // 
            this.a2q4.AutoSize = true;
            this.a2q4.Location = new System.Drawing.Point(9, 70);
            this.a2q4.Name = "a2q4";
            this.a2q4.Size = new System.Drawing.Size(85, 17);
            this.a2q4.TabIndex = 17;
            this.a2q4.TabStop = true;
            this.a2q4.Text = "radioButton2";
            this.a2q4.UseVisualStyleBackColor = true;
            // 
            // a1q4
            // 
            this.a1q4.AutoSize = true;
            this.a1q4.Location = new System.Drawing.Point(9, 46);
            this.a1q4.Name = "a1q4";
            this.a1q4.Size = new System.Drawing.Size(95, 17);
            this.a1q4.TabIndex = 16;
            this.a1q4.TabStop = true;
            this.a1q4.Text = "answer1check";
            this.a1q4.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.a1q4.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "label4";
            // 
            // a4q5
            // 
            this.a4q5.AutoSize = true;
            this.a4q5.Location = new System.Drawing.Point(9, 118);
            this.a4q5.Name = "a4q5";
            this.a4q5.Size = new System.Drawing.Size(85, 17);
            this.a4q5.TabIndex = 24;
            this.a4q5.TabStop = true;
            this.a4q5.Text = "radioButton4";
            this.a4q5.UseVisualStyleBackColor = true;
            // 
            // a3q5
            // 
            this.a3q5.AutoSize = true;
            this.a3q5.Location = new System.Drawing.Point(9, 94);
            this.a3q5.Name = "a3q5";
            this.a3q5.Size = new System.Drawing.Size(85, 17);
            this.a3q5.TabIndex = 23;
            this.a3q5.TabStop = true;
            this.a3q5.Text = "radioButton3";
            this.a3q5.UseVisualStyleBackColor = true;
            // 
            // a2q5
            // 
            this.a2q5.AutoSize = true;
            this.a2q5.Location = new System.Drawing.Point(9, 70);
            this.a2q5.Name = "a2q5";
            this.a2q5.Size = new System.Drawing.Size(85, 17);
            this.a2q5.TabIndex = 22;
            this.a2q5.TabStop = true;
            this.a2q5.Text = "radioButton2";
            this.a2q5.UseVisualStyleBackColor = true;
            // 
            // a1q5
            // 
            this.a1q5.AutoSize = true;
            this.a1q5.Location = new System.Drawing.Point(9, 46);
            this.a1q5.Name = "a1q5";
            this.a1q5.Size = new System.Drawing.Size(95, 17);
            this.a1q5.TabIndex = 21;
            this.a1q5.TabStop = true;
            this.a1q5.Text = "answer1check";
            this.a1q5.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.a1q5.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "label5";
            // 
            // a4q6
            // 
            this.a4q6.AutoSize = true;
            this.a4q6.Location = new System.Drawing.Point(9, 115);
            this.a4q6.Name = "a4q6";
            this.a4q6.Size = new System.Drawing.Size(85, 17);
            this.a4q6.TabIndex = 29;
            this.a4q6.TabStop = true;
            this.a4q6.Text = "radioButton4";
            this.a4q6.UseVisualStyleBackColor = true;
            // 
            // a3q6
            // 
            this.a3q6.AutoSize = true;
            this.a3q6.Location = new System.Drawing.Point(9, 91);
            this.a3q6.Name = "a3q6";
            this.a3q6.Size = new System.Drawing.Size(85, 17);
            this.a3q6.TabIndex = 28;
            this.a3q6.TabStop = true;
            this.a3q6.Text = "radioButton3";
            this.a3q6.UseVisualStyleBackColor = true;
            // 
            // a2q6
            // 
            this.a2q6.AutoSize = true;
            this.a2q6.Location = new System.Drawing.Point(9, 67);
            this.a2q6.Name = "a2q6";
            this.a2q6.Size = new System.Drawing.Size(85, 17);
            this.a2q6.TabIndex = 27;
            this.a2q6.TabStop = true;
            this.a2q6.Text = "radioButton2";
            this.a2q6.UseVisualStyleBackColor = true;
            // 
            // a1q6
            // 
            this.a1q6.AutoSize = true;
            this.a1q6.Location = new System.Drawing.Point(9, 43);
            this.a1q6.Name = "a1q6";
            this.a1q6.Size = new System.Drawing.Size(95, 17);
            this.a1q6.TabIndex = 26;
            this.a1q6.TabStop = true;
            this.a1q6.Text = "answer1check";
            this.a1q6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.a1q6.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "label6";
            // 
            // a4q7
            // 
            this.a4q7.AutoSize = true;
            this.a4q7.Location = new System.Drawing.Point(9, 114);
            this.a4q7.Name = "a4q7";
            this.a4q7.Size = new System.Drawing.Size(85, 17);
            this.a4q7.TabIndex = 34;
            this.a4q7.TabStop = true;
            this.a4q7.Text = "radioButton4";
            this.a4q7.UseVisualStyleBackColor = true;
            // 
            // a3q7
            // 
            this.a3q7.AutoSize = true;
            this.a3q7.Location = new System.Drawing.Point(9, 90);
            this.a3q7.Name = "a3q7";
            this.a3q7.Size = new System.Drawing.Size(85, 17);
            this.a3q7.TabIndex = 33;
            this.a3q7.TabStop = true;
            this.a3q7.Text = "radioButton3";
            this.a3q7.UseVisualStyleBackColor = true;
            // 
            // a2q7
            // 
            this.a2q7.AutoSize = true;
            this.a2q7.Location = new System.Drawing.Point(9, 66);
            this.a2q7.Name = "a2q7";
            this.a2q7.Size = new System.Drawing.Size(85, 17);
            this.a2q7.TabIndex = 32;
            this.a2q7.TabStop = true;
            this.a2q7.Text = "radioButton2";
            this.a2q7.UseVisualStyleBackColor = true;
            // 
            // a1q7
            // 
            this.a1q7.AutoSize = true;
            this.a1q7.Location = new System.Drawing.Point(9, 42);
            this.a1q7.Name = "a1q7";
            this.a1q7.Size = new System.Drawing.Size(95, 17);
            this.a1q7.TabIndex = 31;
            this.a1q7.TabStop = true;
            this.a1q7.Text = "answer1check";
            this.a1q7.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.a1q7.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 30;
            this.label7.Text = "label7";
            // 
            // a4q8
            // 
            this.a4q8.AutoSize = true;
            this.a4q8.Location = new System.Drawing.Point(9, 118);
            this.a4q8.Name = "a4q8";
            this.a4q8.Size = new System.Drawing.Size(85, 17);
            this.a4q8.TabIndex = 39;
            this.a4q8.TabStop = true;
            this.a4q8.Text = "radioButton4";
            this.a4q8.UseVisualStyleBackColor = true;
            // 
            // a3q8
            // 
            this.a3q8.AutoSize = true;
            this.a3q8.Location = new System.Drawing.Point(9, 94);
            this.a3q8.Name = "a3q8";
            this.a3q8.Size = new System.Drawing.Size(85, 17);
            this.a3q8.TabIndex = 38;
            this.a3q8.TabStop = true;
            this.a3q8.Text = "radioButton3";
            this.a3q8.UseVisualStyleBackColor = true;
            // 
            // a2q8
            // 
            this.a2q8.AutoSize = true;
            this.a2q8.Location = new System.Drawing.Point(9, 70);
            this.a2q8.Name = "a2q8";
            this.a2q8.Size = new System.Drawing.Size(85, 17);
            this.a2q8.TabIndex = 37;
            this.a2q8.TabStop = true;
            this.a2q8.Text = "radioButton2";
            this.a2q8.UseVisualStyleBackColor = true;
            // 
            // a1q8
            // 
            this.a1q8.AutoSize = true;
            this.a1q8.Location = new System.Drawing.Point(9, 46);
            this.a1q8.Name = "a1q8";
            this.a1q8.Size = new System.Drawing.Size(95, 17);
            this.a1q8.TabIndex = 36;
            this.a1q8.TabStop = true;
            this.a1q8.Text = "answer1check";
            this.a1q8.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.a1q8.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 35;
            this.label8.Text = "label8";
            // 
            // a4q9
            // 
            this.a4q9.AutoSize = true;
            this.a4q9.Location = new System.Drawing.Point(9, 118);
            this.a4q9.Name = "a4q9";
            this.a4q9.Size = new System.Drawing.Size(85, 17);
            this.a4q9.TabIndex = 44;
            this.a4q9.TabStop = true;
            this.a4q9.Text = "radioButton4";
            this.a4q9.UseVisualStyleBackColor = true;
            // 
            // a3q9
            // 
            this.a3q9.AutoSize = true;
            this.a3q9.Location = new System.Drawing.Point(9, 94);
            this.a3q9.Name = "a3q9";
            this.a3q9.Size = new System.Drawing.Size(85, 17);
            this.a3q9.TabIndex = 43;
            this.a3q9.TabStop = true;
            this.a3q9.Text = "radioButton3";
            this.a3q9.UseVisualStyleBackColor = true;
            this.a3q9.CheckedChanged += new System.EventHandler(this.a3q9_CheckedChanged);
            // 
            // a2q9
            // 
            this.a2q9.AutoSize = true;
            this.a2q9.Location = new System.Drawing.Point(9, 70);
            this.a2q9.Name = "a2q9";
            this.a2q9.Size = new System.Drawing.Size(85, 17);
            this.a2q9.TabIndex = 42;
            this.a2q9.TabStop = true;
            this.a2q9.Text = "radioButton2";
            this.a2q9.UseVisualStyleBackColor = true;
            // 
            // a1q9
            // 
            this.a1q9.AutoSize = true;
            this.a1q9.Location = new System.Drawing.Point(9, 46);
            this.a1q9.Name = "a1q9";
            this.a1q9.Size = new System.Drawing.Size(95, 17);
            this.a1q9.TabIndex = 41;
            this.a1q9.TabStop = true;
            this.a1q9.Text = "answer1check";
            this.a1q9.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.a1q9.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 40;
            this.label9.Text = "label9";
            // 
            // a4q10
            // 
            this.a4q10.AutoSize = true;
            this.a4q10.Location = new System.Drawing.Point(9, 118);
            this.a4q10.Name = "a4q10";
            this.a4q10.Size = new System.Drawing.Size(85, 17);
            this.a4q10.TabIndex = 49;
            this.a4q10.TabStop = true;
            this.a4q10.Text = "radioButton4";
            this.a4q10.UseVisualStyleBackColor = true;
            // 
            // a3q10
            // 
            this.a3q10.AutoSize = true;
            this.a3q10.Location = new System.Drawing.Point(9, 94);
            this.a3q10.Name = "a3q10";
            this.a3q10.Size = new System.Drawing.Size(85, 17);
            this.a3q10.TabIndex = 48;
            this.a3q10.TabStop = true;
            this.a3q10.Text = "radioButton3";
            this.a3q10.UseVisualStyleBackColor = true;
            // 
            // a2q10
            // 
            this.a2q10.AutoSize = true;
            this.a2q10.Location = new System.Drawing.Point(9, 70);
            this.a2q10.Name = "a2q10";
            this.a2q10.Size = new System.Drawing.Size(85, 17);
            this.a2q10.TabIndex = 47;
            this.a2q10.TabStop = true;
            this.a2q10.Text = "radioButton2";
            this.a2q10.UseVisualStyleBackColor = true;
            // 
            // a1q10
            // 
            this.a1q10.AutoSize = true;
            this.a1q10.Location = new System.Drawing.Point(9, 46);
            this.a1q10.Name = "a1q10";
            this.a1q10.Size = new System.Drawing.Size(95, 17);
            this.a1q10.TabIndex = 46;
            this.a1q10.TabStop = true;
            this.a1q10.Text = "answer1check";
            this.a1q10.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.a1q10.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 45;
            this.label10.Text = "label10";
            // 
            // finishButton
            // 
            this.finishButton.Location = new System.Drawing.Point(349, 1510);
            this.finishButton.Name = "finishButton";
            this.finishButton.Size = new System.Drawing.Size(162, 35);
            this.finishButton.TabIndex = 50;
            this.finishButton.Text = "Finish test!";
            this.finishButton.UseVisualStyleBackColor = true;
            this.finishButton.Click += new System.EventHandler(this.finishButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.a1q1);
            this.groupBox1.Controls.Add(this.a2q1);
            this.groupBox1.Controls.Add(this.a3q1);
            this.groupBox1.Controls.Add(this.a4q1);
            this.groupBox1.Location = new System.Drawing.Point(111, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(633, 141);
            this.groupBox1.TabIndex = 51;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Question1";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.a1q2);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.a2q2);
            this.groupBox2.Controls.Add(this.a3q2);
            this.groupBox2.Controls.Add(this.a4q2);
            this.groupBox2.Location = new System.Drawing.Point(111, 159);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(633, 140);
            this.groupBox2.TabIndex = 52;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Question2";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.a3q3);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.a1q3);
            this.groupBox3.Controls.Add(this.a2q3);
            this.groupBox3.Controls.Add(this.a4q3);
            this.groupBox3.Location = new System.Drawing.Point(111, 309);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(633, 141);
            this.groupBox3.TabIndex = 53;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Question3";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.a1q4);
            this.groupBox4.Controls.Add(this.a2q4);
            this.groupBox4.Controls.Add(this.a3q4);
            this.groupBox4.Controls.Add(this.a4q4);
            this.groupBox4.Location = new System.Drawing.Point(111, 457);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(633, 144);
            this.groupBox4.TabIndex = 54;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Question4";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.a1q5);
            this.groupBox5.Controls.Add(this.a2q5);
            this.groupBox5.Controls.Add(this.a3q5);
            this.groupBox5.Controls.Add(this.a4q5);
            this.groupBox5.Location = new System.Drawing.Point(111, 608);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(633, 147);
            this.groupBox5.TabIndex = 55;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Question5";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.a2q6);
            this.groupBox6.Controls.Add(this.label6);
            this.groupBox6.Controls.Add(this.a1q6);
            this.groupBox6.Controls.Add(this.a3q6);
            this.groupBox6.Controls.Add(this.a4q6);
            this.groupBox6.Location = new System.Drawing.Point(111, 762);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(633, 138);
            this.groupBox6.TabIndex = 56;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Question6";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.a3q7);
            this.groupBox7.Controls.Add(this.label7);
            this.groupBox7.Controls.Add(this.a1q7);
            this.groupBox7.Controls.Add(this.a2q7);
            this.groupBox7.Controls.Add(this.a4q7);
            this.groupBox7.Location = new System.Drawing.Point(111, 907);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(633, 140);
            this.groupBox7.TabIndex = 57;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Question7";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.a3q8);
            this.groupBox8.Controls.Add(this.label8);
            this.groupBox8.Controls.Add(this.a1q8);
            this.groupBox8.Controls.Add(this.a2q8);
            this.groupBox8.Controls.Add(this.a4q8);
            this.groupBox8.Location = new System.Drawing.Point(111, 1054);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(633, 148);
            this.groupBox8.TabIndex = 58;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Question8";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label9);
            this.groupBox9.Controls.Add(this.a1q9);
            this.groupBox9.Controls.Add(this.a2q9);
            this.groupBox9.Controls.Add(this.a3q9);
            this.groupBox9.Controls.Add(this.a4q9);
            this.groupBox9.Location = new System.Drawing.Point(111, 1209);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(633, 142);
            this.groupBox9.TabIndex = 59;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Question9";
            this.groupBox9.Enter += new System.EventHandler(this.groupBox9_Enter);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label10);
            this.groupBox10.Controls.Add(this.a1q10);
            this.groupBox10.Controls.Add(this.a2q10);
            this.groupBox10.Controls.Add(this.a3q10);
            this.groupBox10.Controls.Add(this.a4q10);
            this.groupBox10.Location = new System.Drawing.Point(111, 1358);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(646, 146);
            this.groupBox10.TabIndex = 60;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Question10";
            // 
            // TestMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(825, 645);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.finishButton);
            this.Name = "TestMenu";
            this.Text = "Test";
            this.Load += new System.EventHandler(this.Test_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton a1q1;
        private System.Windows.Forms.RadioButton a2q1;
        private System.Windows.Forms.RadioButton a3q1;
        private System.Windows.Forms.RadioButton a4q1;
        private System.Windows.Forms.RadioButton a4q2;
        private System.Windows.Forms.RadioButton a3q2;
        private System.Windows.Forms.RadioButton a2q2;
        private System.Windows.Forms.RadioButton a1q2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton a4q3;
        private System.Windows.Forms.RadioButton a3q3;
        private System.Windows.Forms.RadioButton a2q3;
        private System.Windows.Forms.RadioButton a1q3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton a4q4;
        private System.Windows.Forms.RadioButton a3q4;
        private System.Windows.Forms.RadioButton a2q4;
        private System.Windows.Forms.RadioButton a1q4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton a4q5;
        private System.Windows.Forms.RadioButton a3q5;
        private System.Windows.Forms.RadioButton a2q5;
        private System.Windows.Forms.RadioButton a1q5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton a4q6;
        private System.Windows.Forms.RadioButton a3q6;
        private System.Windows.Forms.RadioButton a2q6;
        private System.Windows.Forms.RadioButton a1q6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton a4q7;
        private System.Windows.Forms.RadioButton a3q7;
        private System.Windows.Forms.RadioButton a2q7;
        private System.Windows.Forms.RadioButton a1q7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton a4q8;
        private System.Windows.Forms.RadioButton a3q8;
        private System.Windows.Forms.RadioButton a2q8;
        private System.Windows.Forms.RadioButton a1q8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton a4q9;
        private System.Windows.Forms.RadioButton a3q9;
        private System.Windows.Forms.RadioButton a2q9;
        private System.Windows.Forms.RadioButton a1q9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton a4q10;
        private System.Windows.Forms.RadioButton a3q10;
        private System.Windows.Forms.RadioButton a2q10;
        private System.Windows.Forms.RadioButton a1q10;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button finishButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
    }
}