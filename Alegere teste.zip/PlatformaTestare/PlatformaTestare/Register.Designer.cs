﻿namespace PlatformaTestare
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.usernameText = new System.Windows.Forms.TextBox();
            this.passwordText = new System.Windows.Forms.TextBox();
            this.emailText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.codProfesorTextBox = new System.Windows.Forms.TextBox();
            this.CodProfesroLabel = new System.Windows.Forms.Label();
            this.checkIfProfBox = new System.Windows.Forms.CheckBox();
            this.CNPTextBox = new System.Windows.Forms.TextBox();
            this.CNP = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // usernameText
            // 
            this.usernameText.Location = new System.Drawing.Point(24, 92);
            this.usernameText.Name = "usernameText";
            this.usernameText.Size = new System.Drawing.Size(186, 20);
            this.usernameText.TabIndex = 0;
            this.usernameText.TextChanged += new System.EventHandler(this.usernameText_TextChanged);
            // 
            // passwordText
            // 
            this.passwordText.Location = new System.Drawing.Point(24, 135);
            this.passwordText.Name = "passwordText";
            this.passwordText.Size = new System.Drawing.Size(186, 20);
            this.passwordText.TabIndex = 1;
            this.passwordText.TextChanged += new System.EventHandler(this.passwordText_TextChanged);
            // 
            // emailText
            // 
            this.emailText.Location = new System.Drawing.Point(24, 179);
            this.emailText.Name = "emailText";
            this.emailText.Size = new System.Drawing.Size(186, 20);
            this.emailText.TabIndex = 2;
            this.emailText.TextChanged += new System.EventHandler(this.emailText_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Username";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "E-mail";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(24, 362);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 39);
            this.button1.TabIndex = 6;
            this.button1.Text = "Register";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Location = new System.Drawing.Point(126, 362);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 39);
            this.button2.TabIndex = 7;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // codProfesorTextBox
            // 
            this.codProfesorTextBox.Location = new System.Drawing.Point(24, 268);
            this.codProfesorTextBox.Name = "codProfesorTextBox";
            this.codProfesorTextBox.Size = new System.Drawing.Size(186, 20);
            this.codProfesorTextBox.TabIndex = 8;
            // 
            // CodProfesroLabel
            // 
            this.CodProfesroLabel.AutoSize = true;
            this.CodProfesroLabel.Location = new System.Drawing.Point(24, 237);
            this.CodProfesroLabel.Name = "CodProfesroLabel";
            this.CodProfesroLabel.Size = new System.Drawing.Size(68, 13);
            this.CodProfesroLabel.TabIndex = 9;
            this.CodProfesroLabel.Text = "Cod Profesor";
            this.CodProfesroLabel.Click += new System.EventHandler(this.CodProfesroLabel_Click);
            // 
            // checkIfProfBox
            // 
            this.checkIfProfBox.AutoSize = true;
            this.checkIfProfBox.Location = new System.Drawing.Point(99, 237);
            this.checkIfProfBox.Name = "checkIfProfBox";
            this.checkIfProfBox.Size = new System.Drawing.Size(151, 17);
            this.checkIfProfBox.TabIndex = 10;
            this.checkIfProfBox.Text = "Bifati daca sunteti profesor";
            this.checkIfProfBox.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.checkIfProfBox.UseVisualStyleBackColor = true;
            this.checkIfProfBox.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // CNPTextBox
            // 
            this.CNPTextBox.Location = new System.Drawing.Point(24, 336);
            this.CNPTextBox.Name = "CNPTextBox";
            this.CNPTextBox.Size = new System.Drawing.Size(186, 20);
            this.CNPTextBox.TabIndex = 8;
            this.CNPTextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // CNP
            // 
            this.CNP.AutoSize = true;
            this.CNP.Location = new System.Drawing.Point(24, 305);
            this.CNP.Name = "CNP";
            this.CNP.Size = new System.Drawing.Size(112, 13);
            this.CNP.TabIndex = 11;
            this.CNP.Text = "Cod Numeric Personal";
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.CNP);
            this.Controls.Add(this.checkIfProfBox);
            this.Controls.Add(this.CodProfesroLabel);
            this.Controls.Add(this.CNPTextBox);
            this.Controls.Add(this.codProfesorTextBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.emailText);
            this.Controls.Add(this.passwordText);
            this.Controls.Add(this.usernameText);
            this.Name = "Register";
            this.Text = "Register";
            this.Load += new System.EventHandler(this.Register_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox usernameText;
        private System.Windows.Forms.TextBox passwordText;
        private System.Windows.Forms.TextBox emailText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox codProfesorTextBox;
        private System.Windows.Forms.Label CodProfesroLabel;
        private System.Windows.Forms.CheckBox checkIfProfBox;
        private System.Windows.Forms.TextBox CNPTextBox;
        private System.Windows.Forms.Label CNP;
    }
}