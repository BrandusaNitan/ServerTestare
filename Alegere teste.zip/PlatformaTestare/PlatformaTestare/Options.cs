﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PlatformaTestare
{
    public partial class Options : Form
    {
        User userData = new User();
        public Options()
        {
            InitializeComponent();
        }
        public Options(User user)
        {

            userData.assign(user.name ,user.isProf,user.materie);
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void backButton_Click(object sender, EventArgs e)
        {
            MainMenu openMainmenu = new MainMenu(userData);
            openMainmenu.Show();
            this.Visible = false;
        }

        private void changePasswordButton_Click(object sender, EventArgs e)
        {
           
        }

        private void userChangePassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void changeUserButton_Click(object sender, EventArgs e)
        {
           

        }
    }
}
