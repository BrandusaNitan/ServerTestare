﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlatformaTestare
{
    class Tests
    {
        List<Question> question = new List<Question>() ;
        static Random _random = new Random();
        public int[] answers = new int[11];
        public Tests()
        {
            
            int i = 0;
            int count = 0;
            List<int> array;
            array = new List<int>();
            string line;
            List<String> lines2;
            lines2 = new List<String>();
            System.IO.StreamReader file = new System.IO.StreamReader(@"C:\Users\prejb\Desktop\PlatformaTestare\PlatformaTestare\Teste.txt");
            while ((line = file.ReadLine()) != null)
            {

                lines2.Add(line);
                count++;
                
            }
            file.Close();

           
            for (i = 0; i < lines2.Count - 4; i = i + 5)
            {
                Question aux = new Question();
                aux.question = lines2[i];
                aux.answer1 = lines2[i + 1];
                aux.answer2 = lines2[i + 2];
                aux.answer3 = lines2[i + 3];
                aux.answer4 = lines2[i + 4];
                question.Add(aux);
                
            }



            
            int n = question.Count;
            for (i = 0; i < n; i++)
            {
                int r = i + (int)(_random.NextDouble() * (n - i));
                Question t = new Question();
                t = question[r];
                question[r] = question[i];
                question[i] = t;
            }
           
          
            for (i = 0; i <=10; i++)
            {
              
                if (question[i].answer1.Contains("*"))
                {
                    this.answers[i] = 1;
                    question[i].answer1=question[i].answer1.Remove(0,1);
                }
                if (question[i].answer2.Contains("*"))
                {
                    this.answers[i] = 2;
                    question[i].answer2 = question[i].answer2.Remove(0, 1);
                }
                if (question[i].answer3.Contains("*"))
                {
                    this.answers[i] = 3;
                    question[i].answer3 = question[i].answer3.Remove(0, 1);
                }
                if (question[i].answer4.Contains("*"))
                {
                    this.answers[i] = 4;
                    question[i].answer4 = question[i].answer4.Remove(0, 1);
                }
                    
            }
            
        }
        public Question getQuestion(int i)
        {
            return question[i];
        }

    }
}
