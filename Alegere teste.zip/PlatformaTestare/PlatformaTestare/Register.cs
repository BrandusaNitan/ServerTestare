﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PlatformaTestare
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(Helper.ConnectionValue("PlatformaTestare"));
            con.Open();
            if (passwordText.Text.Length < 6)
            {
                passwordText.ResetText();
                usernameText.ResetText();
                emailText.ResetText();
                codProfesorTextBox.ResetText();
                CNPTextBox.ResetText();
                checkIfProfBox.ResetText();
                MessageBox.Show("Password is too short!");
            }
            else 
            {

                if (checkIfProfBox.Checked)
                {
                    SqlCommand cmd_verificaraUsername = new SqlCommand("SELECT * FROM [UtilizatoriProfesori] WHERE username='" + usernameText.Text + "'", con); //Verificare daca username se afla in baza de date
                    SqlDataAdapter sda_VerificareUsername = new SqlDataAdapter(cmd_verificaraUsername);
                    DataTable dtbl_verificareUsername = new DataTable();
                    sda_VerificareUsername.Fill(dtbl_verificareUsername);
                    if (dtbl_verificareUsername.Rows.Count == 0)
                    {
                        SqlCommand cmd_codProfesor = new SqlCommand("SELECT * FROM [Profesori] WHERE CodProfesor=" + codProfesorTextBox.Text, con); //Verificare ca profesorul se afla in baza de date pe baza unui cod special
                        SqlDataAdapter sda = new SqlDataAdapter(cmd_codProfesor);
                        DataTable dtbl = new DataTable();
                        sda.Fill(dtbl);

                        if (dtbl.Rows.Count > 0)
                        {
                            Encrypter encryptPassword = new Encrypter();
                            SqlCommand cmd_AdaugaUtilizatorProfesor = new SqlCommand("INSERT INTO [UtilizatoriProfesori] (ID_UtilizatorProfesor,username,parola) VALUES (@ID,@username,@parola)", con);
                            cmd_AdaugaUtilizatorProfesor.Parameters.AddWithValue("@ID", dtbl.Rows[0][0]);
                            cmd_AdaugaUtilizatorProfesor.Parameters.AddWithValue("@parola", encryptPassword.encryptPassword(passwordText.Text));
                            cmd_AdaugaUtilizatorProfesor.Parameters.AddWithValue("@username", usernameText.Text);
                            try
                            {
                                cmd_AdaugaUtilizatorProfesor.ExecuteNonQuery();
                                con.Close();
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Ooops, deja aveti cont");
                                passwordText.ResetText();
                                usernameText.ResetText();
                                emailText.ResetText();
                                codProfesorTextBox.ResetText();
                                CNPTextBox.ResetText();
                                checkIfProfBox.ResetText();
                            }
                            LogIn openLogIn = new LogIn();
                            openLogIn.Show();
                            this.Hide();
                        }
                        else
                        {

                            MessageBox.Show("Codul Profesorului este invalid");
                            passwordText.ResetText();
                            usernameText.ResetText();
                            emailText.ResetText();
                            codProfesorTextBox.ResetText();
                            CNPTextBox.ResetText();
                            checkIfProfBox.ResetText();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Username-ul deja exista");
                        passwordText.ResetText();
                        usernameText.ResetText();
                        emailText.ResetText();
                        codProfesorTextBox.ResetText();
                        CNPTextBox.ResetText();
                        checkIfProfBox.ResetText();
                    }
                }
                else
                {
                    if(CNPTextBox.Text.Length == 13)
                    {
                        SqlCommand cmd_verificaraUsername = new SqlCommand("SELECT * FROM [UtilizatoriStudenti] WHERE username='" + usernameText.Text + "'", con); //Verificare daca username se afla in baza de date
                        SqlDataAdapter sda_VerificareUsername = new SqlDataAdapter(cmd_verificaraUsername);
                        DataTable dtbl_verificareUsername = new DataTable();
                        sda_VerificareUsername.Fill(dtbl_verificareUsername);

                        if (dtbl_verificareUsername.Rows.Count == 0)
                        {
                            SqlCommand cmd_CNPStudent = new SqlCommand("SELECT * FROM [Studenti] WHERE [CNP]=" + CNPTextBox.Text.ToString(), con);
                            SqlDataAdapter sda2 = new SqlDataAdapter(cmd_CNPStudent);
                            DataTable dtbl2 = new DataTable();
                            sda2.Fill(dtbl2);
                            if (dtbl2.Rows.Count > 0)
                            {
                                Encrypter encryptPassword = new Encrypter();
                                SqlCommand cmd_AdaugaUtilizatorStudent = new SqlCommand("INSERT INTO [UtilizatoriStudenti] (ID_UtilizatorStudent,username,parola) VALUES (@ID,@username,@parola)", con);
                                cmd_AdaugaUtilizatorStudent.Parameters.AddWithValue("@ID", dtbl2.Rows[0][0]);
                                cmd_AdaugaUtilizatorStudent.Parameters.AddWithValue("@parola", encryptPassword.encryptPassword(passwordText.Text));
                                cmd_AdaugaUtilizatorStudent.Parameters.AddWithValue("@username", usernameText.Text);
                                try
                                {
                                    cmd_AdaugaUtilizatorStudent.ExecuteNonQuery();
                                    con.Close();
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("Ooops, deja aveti cont");
                                    passwordText.ResetText();
                                    usernameText.ResetText();
                                    emailText.ResetText();
                                    codProfesorTextBox.ResetText();
                                    CNPTextBox.ResetText();
                                    checkIfProfBox.ResetText();
                                }
                                LogIn openLogIn = new LogIn();
                                openLogIn.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Ooops, nu sunteti student la noi!");
                                passwordText.ResetText();
                                usernameText.ResetText();
                                emailText.ResetText();
                                codProfesorTextBox.ResetText();
                                CNPTextBox.ResetText();
                                checkIfProfBox.ResetText();
                            }
                        }

                        else
                        {
                            MessageBox.Show("Username-ul exista deja!");
                            passwordText.ResetText();
                            usernameText.ResetText();
                            emailText.ResetText();
                            codProfesorTextBox.ResetText();
                            CNPTextBox.ResetText();
                            checkIfProfBox.ResetText();
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("CNP invalid");
                        passwordText.ResetText();
                        usernameText.ResetText();
                        emailText.ResetText();
                        codProfesorTextBox.ResetText();
                        CNPTextBox.ResetText();
                        checkIfProfBox.ResetText();
                    }
                    
                }
                
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LogIn openLogIn = new LogIn();
            openLogIn.Show();
            this.Hide();
        }

        private void usernameText_TextChanged(object sender, EventArgs e)
        {

        }

        private void passwordText_TextChanged(object sender, EventArgs e)
        {

        }

        private void emailText_TextChanged(object sender, EventArgs e)
        {

        }

        private void Register_Load(object sender, EventArgs e)
        {

        }

        private void CodProfesroLabel_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
