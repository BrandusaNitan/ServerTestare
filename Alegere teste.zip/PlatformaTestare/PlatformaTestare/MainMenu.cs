﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PlatformaTestare
{ 
    public partial class MainMenu : Form
    {
        User userData = new User();

        public MainMenu()
        {
            InitializeComponent();
        }
        public MainMenu(User user)
        {
            InitializeComponent();
            userData.assign(user.name, user.isProf, user.materie);
            welcomeLabel.Text = "Welcome, " + userData.name;
        }

        public MainMenu(User user, bool newScore)
        {
            
                InitializeComponent();
                userData.assign(user.name, user.isProf,user.materie);
                welcomeLabel.Text = "Welcome, " + userData.name;

        }
        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void MainMenu_Load(object sender, EventArgs e)
        {
            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void optionsButton_Click(object sender, EventArgs e)
        {
            Options openOptions = new Options(userData);
            openOptions.Show();
            this.Visible = false;
        }

        private void testButton_Click(object sender, EventArgs e)
        {
            //FOLOSESTI ISPROF PENTRU PROFESORI SI USERI GG.
            TestMenu openTest = new TestMenu(userData);
            openTest.Show();
            this.Hide();
        }

        private void rankingButton_Click(object sender, EventArgs e)
        {
            if(userData.isProf == true)
            {
                TestProfesori openTestProfesori = new TestProfesori(userData);
                openTestProfesori.Show();
                this.Hide();
                
            }
        }
    }
}
