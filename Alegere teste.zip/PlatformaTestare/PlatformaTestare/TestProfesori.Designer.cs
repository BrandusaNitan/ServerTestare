﻿namespace PlatformaTestare
{
    partial class TestProfesori
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.testeGrid = new System.Windows.Forms.DataGridView();
            this.serverDataSet = new PlatformaTestare.ServerDataSet();
            this.serverDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.TestIDTextBox = new System.Windows.Forms.TextBox();
            this.GrupaTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.testeGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serverDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serverDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // testeGrid
            // 
            this.testeGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.testeGrid.Location = new System.Drawing.Point(216, 29);
            this.testeGrid.Name = "testeGrid";
            this.testeGrid.ReadOnly = true;
            this.testeGrid.Size = new System.Drawing.Size(533, 504);
            this.testeGrid.TabIndex = 0;
            this.testeGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // serverDataSet
            // 
            this.serverDataSet.DataSetName = "ServerDataSet";
            this.serverDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // serverDataSetBindingSource
            // 
            this.serverDataSetBindingSource.DataSource = this.serverDataSet;
            this.serverDataSetBindingSource.Position = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 29);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(198, 50);
            this.button1.TabIndex = 1;
            this.button1.Text = "Alege Testul";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // TestIDTextBox
            // 
            this.TestIDTextBox.Location = new System.Drawing.Point(86, 109);
            this.TestIDTextBox.Name = "TestIDTextBox";
            this.TestIDTextBox.Size = new System.Drawing.Size(45, 20);
            this.TestIDTextBox.TabIndex = 2;
            // 
            // GrupaTextBox
            // 
            this.GrupaTextBox.Location = new System.Drawing.Point(86, 155);
            this.GrupaTextBox.Name = "GrupaTextBox";
            this.GrupaTextBox.Size = new System.Drawing.Size(45, 20);
            this.GrupaTextBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Test";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Grupa";
            // 
            // TestProfesori
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GrupaTextBox);
            this.Controls.Add(this.TestIDTextBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.testeGrid);
            this.Name = "TestProfesori";
            this.Text = "TestProfesori";
            ((System.ComponentModel.ISupportInitialize)(this.testeGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serverDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serverDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView testeGrid;
        private ServerDataSet serverDataSet;
        private System.Windows.Forms.BindingSource serverDataSetBindingSource;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox TestIDTextBox;
        private System.Windows.Forms.TextBox GrupaTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}