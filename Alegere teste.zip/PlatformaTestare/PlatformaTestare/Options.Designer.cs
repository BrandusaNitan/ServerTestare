﻿namespace PlatformaTestare
{
    partial class Options
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.optionLabel = new System.Windows.Forms.Label();
            this.changepasswdLabel = new System.Windows.Forms.Label();
            this.oldPasswdLabel = new System.Windows.Forms.Label();
            this.newPasswdLabel = new System.Windows.Forms.Label();
            this.oldPasswordText = new System.Windows.Forms.TextBox();
            this.newPasswordText = new System.Windows.Forms.TextBox();
            this.changePasswordButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.userChangeText = new System.Windows.Forms.TextBox();
            this.userChangePassword = new System.Windows.Forms.TextBox();
            this.userChangeLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.changeUserButton = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.newPasswordText2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // optionLabel
            // 
            this.optionLabel.AutoSize = true;
            this.optionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optionLabel.Location = new System.Drawing.Point(12, 9);
            this.optionLabel.Name = "optionLabel";
            this.optionLabel.Size = new System.Drawing.Size(86, 25);
            this.optionLabel.TabIndex = 0;
            this.optionLabel.Text = "Options";
            // 
            // changepasswdLabel
            // 
            this.changepasswdLabel.AutoSize = true;
            this.changepasswdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changepasswdLabel.Location = new System.Drawing.Point(14, 56);
            this.changepasswdLabel.Name = "changepasswdLabel";
            this.changepasswdLabel.Size = new System.Drawing.Size(163, 24);
            this.changepasswdLabel.TabIndex = 1;
            this.changepasswdLabel.Text = "Change password";
            // 
            // oldPasswdLabel
            // 
            this.oldPasswdLabel.AutoSize = true;
            this.oldPasswdLabel.Location = new System.Drawing.Point(18, 94);
            this.oldPasswdLabel.Name = "oldPasswdLabel";
            this.oldPasswdLabel.Size = new System.Drawing.Size(71, 13);
            this.oldPasswdLabel.TabIndex = 2;
            this.oldPasswdLabel.Text = "Old password";
            this.oldPasswdLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // newPasswdLabel
            // 
            this.newPasswdLabel.AutoSize = true;
            this.newPasswdLabel.Location = new System.Drawing.Point(18, 133);
            this.newPasswdLabel.Name = "newPasswdLabel";
            this.newPasswdLabel.Size = new System.Drawing.Size(78, 13);
            this.newPasswdLabel.TabIndex = 3;
            this.newPasswdLabel.Text = "New Password";
            this.newPasswdLabel.Click += new System.EventHandler(this.label2_Click);
            // 
            // oldPasswordText
            // 
            this.oldPasswordText.Location = new System.Drawing.Point(21, 110);
            this.oldPasswordText.Name = "oldPasswordText";
            this.oldPasswordText.Size = new System.Drawing.Size(113, 20);
            this.oldPasswordText.TabIndex = 4;
            // 
            // newPasswordText
            // 
            this.newPasswordText.Location = new System.Drawing.Point(21, 150);
            this.newPasswordText.Name = "newPasswordText";
            this.newPasswordText.Size = new System.Drawing.Size(113, 20);
            this.newPasswordText.TabIndex = 5;
            // 
            // changePasswordButton
            // 
            this.changePasswordButton.Location = new System.Drawing.Point(20, 198);
            this.changePasswordButton.Name = "changePasswordButton";
            this.changePasswordButton.Size = new System.Drawing.Size(113, 23);
            this.changePasswordButton.TabIndex = 6;
            this.changePasswordButton.Text = "Change Password";
            this.changePasswordButton.UseVisualStyleBackColor = true;
            this.changePasswordButton.Click += new System.EventHandler(this.changePasswordButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 224);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 24);
            this.label1.TabIndex = 7;
            this.label1.Text = "Change Username";
            // 
            // userChangeText
            // 
            this.userChangeText.Location = new System.Drawing.Point(21, 271);
            this.userChangeText.Name = "userChangeText";
            this.userChangeText.Size = new System.Drawing.Size(113, 20);
            this.userChangeText.TabIndex = 8;
            // 
            // userChangePassword
            // 
            this.userChangePassword.Location = new System.Drawing.Point(21, 315);
            this.userChangePassword.Name = "userChangePassword";
            this.userChangePassword.Size = new System.Drawing.Size(113, 20);
            this.userChangePassword.TabIndex = 9;
            this.userChangePassword.TextChanged += new System.EventHandler(this.userChangePassword_TextChanged);
            // 
            // userChangeLabel
            // 
            this.userChangeLabel.AutoSize = true;
            this.userChangeLabel.Location = new System.Drawing.Point(21, 252);
            this.userChangeLabel.Name = "userChangeLabel";
            this.userChangeLabel.Size = new System.Drawing.Size(69, 13);
            this.userChangeLabel.TabIndex = 10;
            this.userChangeLabel.Text = "User Change";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 298);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Password";
            // 
            // changeUserButton
            // 
            this.changeUserButton.Location = new System.Drawing.Point(19, 351);
            this.changeUserButton.Name = "changeUserButton";
            this.changeUserButton.Size = new System.Drawing.Size(114, 23);
            this.changeUserButton.TabIndex = 12;
            this.changeUserButton.Text = "Change User";
            this.changeUserButton.UseVisualStyleBackColor = true;
            this.changeUserButton.Click += new System.EventHandler(this.changeUserButton_Click);
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(21, 380);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(113, 23);
            this.backButton.TabIndex = 13;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // newPasswordText2
            // 
            this.newPasswordText2.Location = new System.Drawing.Point(21, 177);
            this.newPasswordText2.Name = "newPasswordText2";
            this.newPasswordText2.Size = new System.Drawing.Size(113, 20);
            this.newPasswordText2.TabIndex = 14;
            // 
            // Options
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.newPasswordText2);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.changeUserButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.userChangeLabel);
            this.Controls.Add(this.userChangePassword);
            this.Controls.Add(this.userChangeText);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.changePasswordButton);
            this.Controls.Add(this.newPasswordText);
            this.Controls.Add(this.oldPasswordText);
            this.Controls.Add(this.newPasswdLabel);
            this.Controls.Add(this.oldPasswdLabel);
            this.Controls.Add(this.changepasswdLabel);
            this.Controls.Add(this.optionLabel);
            this.Name = "Options";
            this.Text = "Options";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label optionLabel;
        private System.Windows.Forms.Label changepasswdLabel;
        private System.Windows.Forms.Label oldPasswdLabel;
        private System.Windows.Forms.Label newPasswdLabel;
        private System.Windows.Forms.TextBox oldPasswordText;
        private System.Windows.Forms.TextBox newPasswordText;
        private System.Windows.Forms.Button changePasswordButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox userChangeText;
        private System.Windows.Forms.TextBox userChangePassword;
        private System.Windows.Forms.Label userChangeLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button changeUserButton;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.TextBox newPasswordText2;
    }
}